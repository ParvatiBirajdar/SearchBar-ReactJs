import React,{Component} from 'react';
import './App.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import {BrowserRouter as Router} from 'react-router-dom';
import AppContainer from './AppContainter';

class App extends Component {

  constructor(){
    super();
    this.state={
      
    }
  }

  render() { 
    return (
      <div>
               <Router>
                    <AppContainer/>
                  </Router>
  
        {/* <Search/> */}
      </div>

      );
  }
}
 
export default App;

