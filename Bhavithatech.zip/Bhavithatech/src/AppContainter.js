import React, {Component} from 'react';
import {Route, Switch, withRouter} from 'react-router-dom';
import Product from './core/Component/Product';
import ProductList from './core/Component/ProductList';
import ProductView from './core/Component/ProductView';


class AppContainer extends Component {

    constructor(props) {
      super(props);
      this.state = {
      };
    }

    
  render() {
    return (
      <div className="App">
          <Switch>
          <Route exact path="/" component={Product}/>
          <Route exact path="/product-list/all/" component={ProductList}/>
          <Route exact path="/product-view/" component={ProductView}/>
          </Switch>
          </div>
)
}
}
export default (withRouter(AppContainer));