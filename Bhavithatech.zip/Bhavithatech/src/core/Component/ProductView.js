import React from "react";
import {withRouter,Link} from 'react-router-dom';
import Button from "@material-ui/core/Button";
import DummyImage from '../../assets/img/defaultCover.jpg';

class ProductView extends React.Component{
    constructor(props) {
        super(props);
        this.state = {   
        }
    }  

    render(){
        return(
            <div className='container mt-5'>
                <div className='row'>
                    <div className='col-xl-3 col-lg-3 col-md-3 col-12'></div>
                    <div className='col-xl-6 col-lg-6 col-md-6 col-12'>
                <div className='boxshadow p-2'>
                <img 
                src={DummyImage}
                alt='DummyImage'
                className='img-fluid'
                />
                <h4 className='text-center p-2'>Product Name</h4>
                </div>
                <div className='mt-4 text-center'>
                <Link to={'/'}>
                <Button variant="contained" className="mr-2 "
                                                            color="primary">
                                                             Add Cart
                                                            </Button> 
                                                            </Link>
                </div>
                </div>
                </div>
                <div className='col-xl-3 col-lg-3 col-md-3 col-12'>
                    </div>
                </div>
        )
    }
}
export default (withRouter(ProductView))