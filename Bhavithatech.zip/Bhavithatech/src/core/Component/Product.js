import React from "react";
import {Link,withRouter} from 'react-router-dom';
import ProductData from '../../assets/data/ProductData.json';

let users = ProductData.TrulyHyper_Master_Inventory;

class Product extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        searchString: "",
        users: []
      };
      this.handleChange = this.handleChange.bind(this);
    }
  
    componentDidMount() {
      this.setState({
        users: users
      });
      this.refs.search.focus();
    }
  
    handleChange() {
      this.setState({
        searchString: this.refs.search.value
      });
    }
  
    render() {
      let _users = this.state.users;
      let search = this.state.searchString.trim().toLowerCase();
  
      if (search.length > 2) 
      {
        _users = _users.filter(function(user) {
          return user.PROD_NAME.toLowerCase().match(search);
        });
      }
  
      return (
        <div className='container mt-4'>
          <div className='row'>
            <div className='col-xl-3 col-lg-3 col-md-3 col-12'></div>
            <div className='col-xl-6 col-lg-6 col-md-6 col-12'>
          <h3 className='text-center'>Products</h3>
          <div className='mt-5'>
            <input
              type="text"
              value={this.state.searchString}
              ref="search"
              onChange={this.handleChange}
              placeholder="Type Product Name Here"
            />
            {search.length > 2 &&
          <ul className='list-shadow'>
              {_users.slice(0,5).map(list => {
                return (
                  <li>
                    <Link to={'/product-view/'}>
                    <span style={{fontSize:16}}>{list.PROD_NAME}</span>
                    <span style={{fontSize:12,float:'right'}}>{list.PROD_QTY} {list.PROD_QTY_TYPE}</span>
                    </Link>
                  </li>
                );
              })}
              
              <li className='text-center font-weight-bold'>
              <Link to={'/product-list/all/'} >
                  Show All Products
                </Link>
              </li>
            </ul>
    }
          </div>
          </div>
          <div className='col-xl-3 col-lg-3 col-md-4 col-12'></div>
          </div>
        </div>
      );
    }
  }
  

  export default (withRouter(Product));
