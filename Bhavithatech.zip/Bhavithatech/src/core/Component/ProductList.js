import React from "react";
import {withRouter} from 'react-router-dom';
import Button from "@material-ui/core/Button";
import ProductData from '../../assets/data/ProductData.json';
import DummyImage from '../../assets/img/defaultCover.jpg';

let Products = ProductData.TrulyHyper_Master_Inventory;

class ProductList extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            showMoreProduct: true,
        }
    }  

    handleonClick() {
        this.setState({showMoreProduct: !this.state.showMoreProduct});
    }

    render(){

        let {showMoreProduct} = this.state;

        let ProductsData = (showMoreProduct) ? Products.slice(0,20) : Products.slice(0,40);

        let AllProductsUi = ProductsData.map((data) => {
            return (
                <div className="col-xl-3 col-lg-3 col-md-3 col-12 mb-3">
                    <div className="d-flex flex-column h-100 ">
                        <div className="d-flex flex-column align-items-start h-100 box-shadow p-2">
                            <div className="row d-flex flex-grow-1 boxshadow p-2">
                            <div>
                            <img
                src={DummyImage}
                alt={'DummyImage'}
                className="img-fluid "/>
                    <h6>{data.PROD_NAME} </h6>
                    <span>{data.PROD_QTY}
                     {data.PROD_QTY_TYPE}</span>
                  </div>
       </div>
       </div>
       </div>
       </div>
            )})

        return(
            <div className='container mt-4'>
                <h3>All Products List</h3>
                <div className='row'>
                {AllProductsUi}
                </div>
                <div className="text-center font-dark-blue py-2 cursor" onClick={() => {
                                                        this.handleonClick();
                                                    }}>

                                                        {
                                                            showMoreProduct ? (
                                                            <Button variant="contained" className="mr-2 "
                                                            color="primary">
                                                             Show More
                                                            </Button>
                                                            ) 
                                                            : 
                                                            (
                                                                <Button variant="contained" className="mr-2 "
                                                                color="default">
                                                                 Show Less
                                                                </Button>
                                                            )
                                                        }
                                                    </div>

            </div>
        )
    }

}

export default (withRouter(ProductList));